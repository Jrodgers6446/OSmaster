@echo off
REM OSmaster launcher -- double-click this to open the app.
REM Automatically requests Administrator rights (required for disk/USB operations).

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0OSmaster-GUI.ps1"
if %errorlevel% neq 0 (
    echo.
    echo Something went wrong -- see any messages above.
    pause
)
