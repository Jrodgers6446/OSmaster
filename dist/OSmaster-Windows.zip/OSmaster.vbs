' OSmaster.vbs
' The one file to double-click. First run: creates a Desktop shortcut
' automatically (so you never need this folder again). Every run:
' launches the app with no visible console -- just the app window itself
' (after the one Windows UAC prompt, which is required by Windows for any
' admin-rights app and can't be skipped or hidden).

Set objFSO = CreateObject("Scripting.FileSystemObject")
strFolder = objFSO.GetParentFolderName(WScript.ScriptFullName)
strScript = strFolder & "\OSmaster-GUI.ps1"
strIcon = strFolder & "\icon.ico"

Set objShell = CreateObject("WScript.Shell")
strDesktop = objShell.SpecialFolders("Desktop")
strShortcut = strDesktop & "\OSmaster.lnk"

' Create the Desktop shortcut only if it doesn't already exist.
If Not objFSO.FileExists(strShortcut) Then
    Set objLink = objShell.CreateShortcut(strShortcut)
    objLink.TargetPath = WScript.ScriptFullName
    objLink.WorkingDirectory = strFolder
    objLink.IconLocation = strIcon
    objLink.Description = "OSmaster - OS deployment and console recovery toolkit"
    objLink.Save
End If

' Launch the app itself: elevated, no console window.
Set objAppShell = CreateObject("Shell.Application")
objAppShell.ShellExecute "powershell.exe", _
    "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & strScript & """", _
    "", "runas", 0
