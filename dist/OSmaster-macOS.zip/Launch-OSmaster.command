#!/bin/zsh
# OSmaster macOS launcher -- double-click this in Finder to run.
# Opens Terminal and runs Deploy-macOS.sh from wherever this file lives.

cd "$(dirname "$0")"
chmod +x Deploy-macOS.sh
echo "===================================================="
echo "  OSmaster -- macOS Deployment"
echo "===================================================="
echo ""
echo "Run './Deploy-macOS.sh --help' first if you want the"
echo "full instructions before doing anything destructive."
echo ""
./Deploy-macOS.sh
